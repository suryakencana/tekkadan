# Table Filter

Use Plugin: [bootstrap table filters](https://github.com/lukaskral/bootstrap-table-filter)

## Usage

```html
<script src="extensions/filter/bootstrap-table-filter.js"></script>
```

## Options

### showFilter

* type: Boolean
* description: set true to show filter menu.
* default: `false`
